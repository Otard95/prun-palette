(function () {
    'use strict';

    /******************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    class Deferred {
        constructor() {
            this._resolve = () => { };
            this._reject = () => null;
            this._promise = new Promise((resolve, reject) => {
                this._resolve = resolve;
                this._reject = reject;
            });
        }
        get promise() {
            return this._promise;
        }
        get resolve() {
            return this._resolve;
        }
        get reject() {
            return this._reject;
        }
    }

    class DocumentObserver {
        constructor() {
            this.listeners = {
                added: [],
                removed: [],
                changed: [],
            };
            this.observer = new MutationObserver(this.handleMutations.bind(this));
            this.observer.observe(document.body, {
                childList: true,
                subtree: true,
                characterData: true,
            });
        }
        handleMutations(mutations) {
            mutations.forEach((mutation) => {
                mutation.addedNodes.forEach((node) => {
                    for (const listener of this.listeners.added) {
                        if (node instanceof Element && listener.match(node)) {
                            listener.callback(node);
                            if (listener.once) {
                                this.removeListener('add', listener);
                            }
                            if (listener.consume) {
                                return;
                            }
                        }
                    }
                });
            });
        }
        addListener(on, listener) {
            switch (on) {
                case 'add':
                    this.listeners.added.push(listener);
                    break;
                case 'remove':
                    this.listeners.removed.push(listener);
                    break;
                case 'change':
                    this.listeners.changed.push(listener);
                    break;
            }
        }
        removeListener(on, listener) {
            switch (on) {
                case 'add':
                    this.listeners.added.splice(this.listeners.added.indexOf(listener), 1);
                    break;
                case 'remove':
                    this.listeners.removed.splice(this.listeners.removed.indexOf(listener), 1);
                    break;
                case 'change':
                    this.listeners.changed.splice(this.listeners.changed.indexOf(listener), 1);
                    break;
            }
        }
        waitFor(selector, timeout = 1000) {
            return __awaiter(this, void 0, void 0, function* () {
                const deferred = new Deferred();
                const listener = {
                    match: (element) => {
                        const nodeMatches = element.matches(selector);
                        const nodeHadMatchingChildren = element.querySelector(selector);
                        const match = nodeMatches || !!nodeHadMatchingChildren;
                        console.debug(`[PrUn Palette/DocumentObserver](waitFor) match '${selector}'`, match, {
                            nodeMatches,
                            nodeHadMatchingChildren,
                            element,
                        });
                        return match;
                    },
                    callback: (element) => deferred.resolve(element),
                    once: true,
                };
                const timer = setTimeout(() => {
                    this.removeListener('add', listener);
                    deferred.reject(new Error(`Timeout waiting for element matching selector '${selector}'`));
                }, timeout);
                deferred.promise.then((el) => {
                    clearTimeout(timer);
                    return el;
                });
                this.addListener('add', listener);
                return deferred.promise;
            });
        }
    }

    function changeValue(input, value) {
        // Get the property descriptor for the input element's value property
        var propDescriptor = Object.getOwnPropertyDescriptor(window['HTMLInputElement'].prototype, 'value');
        // Return if the property descriptor is undefined
        if (propDescriptor == undefined) {
            return;
        }
        // Get the native input value setter
        var nativeInputValueSetter = propDescriptor.set;
        // Return if the native input value setter is undefined
        if (nativeInputValueSetter == undefined) {
            return;
        }
        // Call the native input value setter with the input element and the new value
        nativeInputValueSetter.call(input, value);
        // Create a new input event
        var inputEvent = document.createEvent('Event');
        // Initialize the event as an 'input' event, bubbling and cancelable
        inputEvent.initEvent('input', true, true);
        // Dispatch the event to the input element
        input.dispatchEvent(inputEvent);
    }

    /**
     * Memoize a function, caching the result for a given time to live (ttl).
     *
     * @param ttl - Time to live in milliseconds. If not given, the result is cached forever.
     * @returns A function that memoizes the result of the given function
     */
    const memoizee = (func, ttl) => {
        const cache = new Map();
        return function (...args) {
            const key = JSON.stringify(args);
            const cachedValue = cache.get(key);
            if (cachedValue && (!ttl || Date.now() - cachedValue.timestamp < ttl)) {
                return cachedValue.value;
            }
            const result = func(...args);
            cache.set(key, { value: result, timestamp: Date.now() });
            return result;
        };
    };
    /**
     * Decorator for memoizing a function. The result is cached for `ttl` milliseconds.
     *
     * @param ttl - Time to live in milliseconds. If not given, the result is cached forever.
     * @returns A decorator that memoizes the result of the given function
     */
    const memoize = (ttl) => {
        return (_target, _propertyKey, descriptor) => {
            if ('value' in descriptor) {
                const func = descriptor.value;
                descriptor.value = memoizee(func, ttl);
            }
            else if ('get' in descriptor) {
                const func = descriptor.get;
                if (!func)
                    return descriptor;
                descriptor.get = memoizee(func, ttl);
            }
            return descriptor;
        };
    };

    class Apex {
        static hasRequiredElements() {
            return Apex._requiredSelectors.every((selector) => {
                return document.querySelector(selector);
            });
        }
        constructor() {
            const deferred = new Deferred();
            this.readyPromise = deferred.promise;
            if (Apex.hasRequiredElements()) {
                deferred.resolve();
            }
            this.observer = new DocumentObserver();
            this.observer.addListener('add', {
                match: () => {
                    return Apex.hasRequiredElements();
                },
                callback: () => {
                    deferred.resolve();
                },
                once: true
            });
        }
        get ready() {
            return this.readyPromise;
        }
        // @memoize(100)
        // private get screenControls(): HTMLDivElement | null {
        //   return document.querySelector('#TOUR_TARGET_SCREEN_CONTROLS')
        // }
        // @memoize(100)
        // private get screenList(): HTMLUListElement | null {
        //   return document
        //     .querySelector('#TOUR_TARGET_SCREEN_CONTROLS')
        //     ?.querySelector('ul')
        //     ?? null
        // }
        get screens() {
            var _a, _b;
            const screenList = (_b = (_a = document
                .querySelector('#TOUR_TARGET_SCREEN_CONTROLS')) === null || _a === void 0 ? void 0 : _a.querySelector('ul')) !== null && _b !== void 0 ? _b : null;
            if (screenList === null)
                return [];
            const listItems = Array.from(screenList.querySelectorAll('li'));
            return listItems.map((listItem) => {
                var _a;
                const a = listItem.querySelector('a');
                if (!a)
                    return null;
                const name = (_a = a.textContent) === null || _a === void 0 ? void 0 : _a.trim();
                if (!name)
                    return null;
                const href = a.getAttribute('href');
                if (!href)
                    return null;
                let deleteButton = null;
                let copyButton = null;
                listItem.querySelectorAll('div').forEach((div) => {
                    var _a, _b;
                    if (((_a = div.textContent) === null || _a === void 0 ? void 0 : _a.trim().toLowerCase()) === 'del') {
                        deleteButton = div;
                    }
                    else if (((_b = div.textContent) === null || _b === void 0 ? void 0 : _b.trim().toLowerCase()) === 'cpy') {
                        copyButton = div;
                    }
                });
                if (!deleteButton || !copyButton)
                    return null;
                return {
                    name,
                    open: () => location.hash = href,
                    delete: () => deleteButton === null || deleteButton === void 0 ? void 0 : deleteButton.click(),
                    copy: () => copyButton === null || copyButton === void 0 ? void 0 : copyButton.click(),
                };
            }).filter((screen) => screen !== null);
        }
        get newBufferButton() {
            return document.querySelector('#TOUR_TARGET_BUTTON_BUFFER_NEW');
        }
        createBuffer(command) {
            var _a;
            return __awaiter(this, void 0, void 0, function* () {
                if (this.newBufferButton === null)
                    return null;
                const bufferPromise = this.observer.waitFor('#TOUR_TARGET_EMPTY_BUFFER:not(.prun-palette-taken)');
                this.newBufferButton.click();
                const buffer = yield bufferPromise;
                buffer.classList.add('prun-palette-taken');
                if (!command) {
                    return buffer;
                }
                const input = buffer.querySelector('input');
                if (!input) {
                    throw new Error('Could not find input element');
                }
                changeValue(input, command);
                (_a = input.form) === null || _a === void 0 ? void 0 : _a.requestSubmit();
                return buffer;
            });
        }
    }
    Apex._requiredSelectors = [
        '.Frame__main___Psr0SIB',
        '#TOUR_TARGET_BUTTON_BUFFER_NEW',
    ];
    __decorate([
        memoize(100)
    ], Apex.prototype, "screens", null);
    __decorate([
        memoize(100)
    ], Apex.prototype, "newBufferButton", null);

    /**
     * An array which items are one persisted for a given time after the array was
     * last modified.
     */
    class EphemeralArray extends Array {
        constructor(ttl) {
            super();
            this.ttl = ttl;
            this.timeout = null;
            this.onTimeoutHandlers = [];
        }
        push(...items) {
            this.resetTimeout();
            return super.push(...items);
        }
        unshift(...items) {
            this.resetTimeout();
            return super.unshift(...items);
        }
        pop() {
            const item = super.pop();
            this.resetTimeout();
            return item;
        }
        shift() {
            const item = super.shift();
            this.resetTimeout();
            return item;
        }
        resetTimeout() {
            if (this.timeout !== null)
                clearTimeout(this.timeout);
            this.timeout = setTimeout(() => {
                this.onTimeoutHandlers.forEach((handler) => handler(this));
                this.length = 0;
            }, this.ttl);
        }
        onTimeout(callback) {
            this.onTimeoutHandlers.push(callback);
        }
    }

    /**
     * Checks if an array starts with another array.
     * Like String.prototype.startsWith but for arrays.
     *
     * @param array The array to check.
     * @param prefix The prefix to check.
     * @returns True if the array starts with the prefix, false otherwise.
     */
    function arrayStartsWith(array, prefix) {
        if (prefix.length > array.length)
            return false;
        for (let i = 0; i < prefix.length; i++) {
            if (array[i] !== prefix[i])
                return false;
        }
        return true;
    }
    /**
     * Checks if two arrays contain the same elements in the same order.
     *
     * @param a The first array.
     * @param b The second array.
     * @returns True if the arrays are equal, false otherwise.
     */
    function arrayEqual(a, b) {
        if (a.length !== b.length)
            return false;
        for (let i = 0; i < a.length; i++) {
            if (a[i] !== b[i])
                return false;
        }
        return true;
    }
    function matchArrays(a, b) {
        const matches = [];
        if (a.length !== b.length)
            throw new Error('Arrays must be of equal length');
        for (let i = 0; i < a.length; i++) {
            matches.push([a[i], b[i]]);
        }
        return matches;
    }

    // all lovercase letters
    const alphabet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
    const keys = [...alphabet, 'arrowup', 'arrowdown', 'arrowleft', 'arrowright', 'tab', 'escape', 'enter', 'backspace'];
    class Keybinds {
        constructor(element = document.body) {
            this.keybinds = [];
            this.pressedKeys = new EphemeralArray(1000);
            element.addEventListener('keydown', (event) => {
                if (event instanceof KeyboardEvent)
                    this.handleKeyDown(event);
            });
            this.pressedKeys.onTimeout(this.handlePressedOnTimeout.bind(this));
        }
        isKey(keyStr) {
            if (keys.includes(keyStr))
                return true;
            if (!/<(C|A|S){1,3}-\w+>/.test(keyStr))
                return false;
            const [, modifiers, key] = keyStr.match(/<([CAS]+)-(\w+)>/);
            const mods = modifiers.split('');
            return keys.includes(key) && mods.every(m => ['C', 'A', 'S'].includes(m));
        }
        parseBind(bind) {
            const keys = bind.trim().split(/\s+/);
            if (keys.some((key) => !this.isKey(key)))
                throw new Error(`Invalid keybind: ${bind}`);
            return keys;
        }
        addKeybind(bind, command, { preventDefault = true } = {}) {
            const keySequence = this.parseBind(bind);
            if (this.keybinds.some(keybind => arrayEqual(keybind.keySequence, keySequence)))
                throw new Error(`Keybind already exists: ${bind}`);
            this.keybinds.push({
                keySequence,
                command,
                preventDefault,
            });
        }
        removeKeybind(bind) {
            const keySequence = this.parseBind(bind);
            this.keybinds = this.keybinds.filter((keybind) => {
                return !arrayEqual(keybind.keySequence, keySequence);
            });
        }
        keyFromKeyboardEvent(event) {
            const { key, ctrlKey, altKey, shiftKey } = event;
            if (!keys.includes(key.toLowerCase()))
                return null;
            if (!ctrlKey && !altKey && !shiftKey)
                return key.toLowerCase();
            const modifiers = [
                ctrlKey ? 'C' : '',
                altKey ? 'A' : '',
                shiftKey ? 'S' : '',
            ].join('');
            return `<${modifiers}-${key.toLowerCase()}>`;
        }
        handleKeyDown(event) {
            const key = this.keyFromKeyboardEvent(event);
            if (key === null)
                return;
            this.pressedKeys.push(key);
            // Find any keybinds that match the current key presses, including those
            // that could become matching.
            const matchingKeybinds = this.keybinds.filter((keybind) => {
                return arrayStartsWith(keybind.keySequence, this.pressedKeys);
            });
            // If there are no matches we cant do anything
            if (matchingKeybinds.length === 0)
                return;
            // If there are more than one we can't make a decision yet on which is
            // correct.
            if (matchingKeybinds.length > 1) {
                event.preventDefault();
                return;
            }
            // If there is only one match make sure its exact
            const match = this.keybinds
                .find(keybind => arrayEqual(keybind.keySequence, this.pressedKeys));
            if (!match)
                return;
            if (match.preventDefault)
                event.preventDefault();
            match.command(() => event.preventDefault());
            this.pressedKeys.length = 0;
        }
        handlePressedOnTimeout() {
            var _a;
            // Find keybinds that exactly match the current keypresses
            (_a = this.keybinds.find((keybind) => arrayEqual(keybind.keySequence, this.pressedKeys))) === null || _a === void 0 ? void 0 : _a.command(() => { });
        }
    }

    class EventEmitter {
        constructor() {
            this.listeners = {};
        }
        on(event, fn) {
            const listeners = this.listeners[event] || new Set();
            listeners.add({ fn });
            this.listeners[event] = listeners;
        }
        once(event, fn) {
            const listeners = this.listeners[event] || new Set();
            listeners.add({ fn, once: true });
            this.listeners[event] = listeners;
        }
        off(event, fn) {
            const listeners = this.listeners[event];
            if (!listeners)
                return;
            listeners.forEach((listener) => {
                if (listener.fn === fn)
                    listeners.delete(listener);
            });
        }
        emit(event, ...args) {
            const listeners = this.listeners[event];
            if (!listeners)
                return;
            listeners.forEach((listener) => {
                listener.fn(...args);
                if (listener.once)
                    listeners.delete(listener);
            });
        }
        clear() {
            this.listeners = {};
        }
    }

    function isEl(el) {
        return el instanceof HTMLElement
            && typeof (el.on) === 'function'
            && typeof (el.once) === 'function'
            && typeof (el.off) === 'function'
            && typeof (el.emit) === 'function'
            && typeof (el.clear) === 'function'
            && typeof (el.att$) === 'function'
            && typeof (el.onClick$) === 'function'
            && typeof (el.onChange$) === 'function'
            && typeof (el.onKeyUp$) === 'function'
            && typeof (el.onKeyDown$) === 'function'
            && typeof (el.replace$) === 'function'
            && typeof (el.mount$) === 'function'
            && typeof (el.unmount$) === 'function';
    }
    function extendWithEventEmitter(el) {
        const emitter = new EventEmitter();
        el.on = (event, fn) => {
            emitter.on(event, fn);
        };
        el.once = (event, fn) => {
            emitter.once(event, fn);
        };
        el.off = (event, fn) => {
            emitter.off(event, fn);
        };
        el.emit = (event, ...args) => {
            emitter.emit(event, ...args);
        };
        el.clear = () => {
            emitter.clear();
        };
    }
    function tag(name, ...children) {
        const result = document.createElement(name);
        extendWithEventEmitter(result);
        for (const child of children) {
            switch (typeof (child)) {
                case 'string':
                case 'number':
                    result.appendChild(document.createTextNode(String(child)));
                case 'boolean':
                case 'undefined':
                    break;
                default:
                    if (isEl(child))
                        result.appendChild(child);
            }
        }
        result.att$ = function (name, value) {
            this.setAttribute(name, value);
            return this;
        };
        result.onClick$ = function (callback) {
            this.onclick = callback;
            return this;
        };
        result.onChange$ = function (callback) {
            this.onchange = callback;
            return this;
        };
        result.onKeyUp$ = function (callback) {
            this.onkeyup = callback;
            return this;
        };
        result.onKeyDown$ = function (callback) {
            this.onkeydown = callback;
            return this;
        };
        result.replace$ = function (element) {
            this.emit('unmount');
            this.replaceWith(element);
            element.emit('mount');
            return this;
        };
        result.mount$ = function (on) {
            on.appendChild(this);
            this.emit('mount');
            return this;
        };
        result.unmount$ = function () {
            this.emit('unmount');
            this.remove();
            return this;
        };
        result.on('mount', () => {
            children.forEach((child) => {
                if (isEl(child)) {
                    child.emit('mount');
                }
            });
        });
        return result;
    }
    function h3(...children) {
        return tag('h3', ...children);
    }
    function p(...children) {
        return tag('p', ...children);
    }
    function div(...children) {
        return tag('div', ...children);
    }

    const cursorEnd = (el) => {
        const range = document.createRange();
        range.selectNodeContents(el);
        range.collapse(false);
        const selection = window.getSelection();
        selection === null || selection === void 0 ? void 0 : selection.removeAllRanges();
        selection === null || selection === void 0 ? void 0 : selection.addRange(range);
    };
    function paletteInput(path = [], current = '', bestMatch) {
        const input = div(current);
        input
            .att$('contenteditable', 'true')
            .onKeyDown$((e) => {
            if (e.key === 'Tab') {
                e.preventDefault();
                return paletteListener.emit('complete', input.innerText);
            }
            if (e.key === 'Enter') {
                e.preventDefault();
                return paletteListener.emit('submit', input.innerText);
            }
            if (e.key === 'Backspace' && input.innerText === '') {
                e.preventDefault();
                return paletteListener.emit('back');
            }
        })
            .onKeyUp$(() => {
            paletteListener.emit('change', input.innerText);
        });
        const focus = () => {
            input.focus();
            cursorEnd(input);
        };
        input.on('mount', focus);
        const bestMatchSuffix = bestMatch
            ? bestMatch.startsWith(current) ? bestMatch.slice(current.length) : ` · ${bestMatch}`
            : undefined;
        const container = div(...path.map((p) => div(p.concat(' ·')).att$('class', 'palette-input-path')), input, bestMatchSuffix && div(bestMatchSuffix).att$('class', 'palette-input-best-match')).att$('class', 'palette-input');
        container.onClick$(() => focus());
        return container;
    }

    function paletteMatches(topMatches = []) {
        return div(...topMatches.map((match) => {
            return div(div(h3(match.name).att$('class', 'palette-match-name'), p(' - ', match.description).att$('class', 'palette-match-description')).att$('class', 'palette-match-header'), p(match.signature.join(' · ')).att$('class', 'palette-match-usage')).att$('class', 'palette-match');
        }), topMatches.length === 0 && p('No matches found').att$('class', 'palette-match-empty')).att$('class', 'palette-matches');
    }
    var paletteMatches$1 = memoizee(paletteMatches);

    function kbd(...children) {
        return tag('kbd', ...children);
    }

    const paletteListener = new EventEmitter();
    function palette({ fuzzNextArg, getTopMatches, execute, close }) {
        const path = [];
        let current = '';
        let bestMatch = undefined;
        let topMatches = [];
        let paletteInputEl = paletteInput(path, current, bestMatch);
        let topMatchesListEl = paletteMatches$1(topMatches);
        const updatePaletteInput = () => {
            const newPaletteInputEl = paletteInput(path, current, bestMatch);
            paletteInputEl.replace$(newPaletteInputEl);
            paletteInputEl = newPaletteInputEl;
        };
        const updateTopMatches = () => {
            const newTopMatchesEl = paletteMatches$1(topMatches);
            topMatchesListEl.replace$(newTopMatchesEl);
            topMatchesListEl = newTopMatchesEl;
        };
        const onPaletteInputChange = (value) => {
            current = value.trimLeft();
            bestMatch = fuzzNextArg(path, current) || undefined;
            topMatches = getTopMatches(path, current);
            updatePaletteInput();
            updateTopMatches();
        };
        const onPaletteInputComplete = () => {
            if (!bestMatch)
                return;
            path.push(bestMatch);
            current = '';
            bestMatch = undefined;
            topMatches = getTopMatches(path, current);
            updatePaletteInput();
            updateTopMatches();
        };
        const onPaletteInputBack = () => {
            path.pop();
            current = '';
            bestMatch = undefined;
            topMatches = [];
            updatePaletteInput();
            updateTopMatches();
        };
        const onPaletteInputSubmit = () => {
            execute(path, current.trim());
            path.length = 0;
            current = '';
            bestMatch = undefined;
            topMatches = [];
            close();
        };
        const palette = div(div(paletteInputEl, topMatchesListEl, p(kbd('enter'), ' to select | ', kbd('tab'), ' to autocomplete | ', kbd('esc'), ' to close')
            .att$('class', 'palette-help')).att$('class', 'palette'))
            .att$('class', 'palette-container')
            .att$('id', 'prun-palette');
        palette.on('mount', () => {
            console.debug('[PrUn palette] palette mounted');
            paletteListener.on('change', onPaletteInputChange);
            paletteListener.on('complete', onPaletteInputComplete);
            paletteListener.on('back', onPaletteInputBack);
            paletteListener.on('submit', onPaletteInputSubmit);
        });
        palette.on('unmount', () => {
            console.debug('[PrUn palette] palette unmounted');
            paletteListener.off('change', onPaletteInputChange);
            paletteListener.off('complete', onPaletteInputComplete);
            paletteListener.off('back', onPaletteInputBack);
            paletteListener.off('submit', onPaletteInputSubmit);
        });
        return palette;
    }

    const fuzzStrings = (str, options) => {
        const score = (subject, option) => {
            let s = 0;
            let consecutive = 0;
            let i = 0;
            let j = 0;
            while (i < subject.length && subject.length - i <= option.length - j) {
                if (subject[i] === option[j]) {
                    s += ++consecutive;
                    i++;
                    j++;
                    continue;
                }
                consecutive = 0;
                s--;
                j++;
            }
            if (i < subject.length)
                return undefined;
            return s;
        };
        return options.map((option) => score(str.toLowerCase(), option.toLowerCase()));
    };

    var PaletteCommandVariables;
    (function (PaletteCommandVariables) {
        PaletteCommandVariables["PlanetName"] = "{planet-name}";
        PaletteCommandVariables["PlanedId"] = "{planet-id}";
        PaletteCommandVariables["Screen"] = "{screen}";
        PaletteCommandVariables["Command"] = "{command}";
    })(PaletteCommandVariables || (PaletteCommandVariables = {}));
    const isPaletteCommandVariable = (value) => {
        return Object.values(PaletteCommandVariables).includes(value);
    };
    class Palette {
        constructor(apex) {
            this.apex = apex;
            this.show = false;
            this.commands = [];
            const paletteEl = document.getElementById('prun-palette');
            if (paletteEl)
                paletteEl.remove();
        }
        get Open() {
            return this.show;
        }
        addCommand(command) {
            this.commands.push(command);
        }
        removeCommand(name) {
            this.commands = this.commands.filter((command) => command.name !== name);
        }
        toggle() {
            if (this.show) {
                this.close();
            }
            else {
                this.open();
            }
        }
        open() {
            this.show = true;
            if (document.getElementById('prun-palette')) {
                console.debug('[PuUn Palette] Palette already open');
                return;
            }
            console.debug('[PuUn Palette] Rendering palette');
            this.palette = palette({
                fuzzNextArg: this.fuzzyNextArg.bind(this),
                getTopMatches: this.sortedMatches.bind(this),
                execute: this.executeSignature.bind(this),
                close: this.close.bind(this),
            });
            this.palette.mount$(document.body);
        }
        close() {
            this.show = false;
            if (this.palette) {
                this.palette.unmount$();
                console.debug('[PuUn Palette] Removing palette');
            }
            else {
                console.debug('[PuUn Palette] Palette not found');
            }
        }
        signaturesMatches(a, b) {
            if (a.length !== b.length)
                return false;
            return a.every((sig, i) => {
                if (isPaletteCommandVariable(sig) || isPaletteCommandVariable(b[i]))
                    return true;
                return sig === b[i];
            });
        }
        signatureStartsWith(sig, prefix) {
            if (sig.length < prefix.length)
                return false;
            for (let i = 0; i < prefix.length; i++) {
                if (isPaletteCommandVariable(prefix[i]) || isPaletteCommandVariable(sig[i]))
                    continue;
                if (sig[i] !== prefix[i])
                    return false;
            }
            return true;
        }
        getCommandsStartingWithSig(partialSig) {
            return this.commands.filter((command) => this.signatureStartsWith(command.signature, partialSig));
        }
        getCommandMatchingSig(sig) {
            const command = this.commands.find((command) => this.signaturesMatches(sig, command.signature));
            return command || null;
        }
        sortedMatches(partialSig, input) {
            const partialMatches = this.getCommandsStartingWithSig(partialSig);
            if (partialMatches.length === 0)
                return [];
            const exactMatch = this.getCommandMatchingSig(partialSig);
            const matchesWithVariables = partialMatches.filter((command) => isPaletteCommandVariable(command.signature[partialSig.length]));
            const partialCommands = partialMatches.filter((command) => command !== exactMatch
                && !matchesWithVariables.includes(command));
            const nextArgs = partialCommands.map((command) => command.signature[partialSig.length]);
            const scoredCommands = matchArrays(partialCommands, fuzzStrings(input, nextArgs))
                .filter((match) => match[1] !== undefined)
                .sort((a, b) => b[1] - a[1]);
            return [
                input === '' && exactMatch,
                ...matchesWithVariables,
                ...scoredCommands.map((match) => match[0]),
            ].filter((command) => !!command);
        }
        fuzzyNextArg(partialSig, input) {
            if (input.length === 0)
                return null;
            const partialMatches = this.getCommandsStartingWithSig(partialSig)
                .filter((command) => {
                if (isPaletteCommandVariable(command.signature[partialSig.length])
                    && command.signature[partialSig.length] !== PaletteCommandVariables.Screen)
                    return false;
                return command.signature.length > partialSig.length;
            });
            if (partialMatches.length === 0)
                return null;
            const nextArgs = partialMatches.map((command) => {
                const nextArg = command.signature[partialSig.length];
                if (!isPaletteCommandVariable(nextArg))
                    return nextArg;
                if (nextArg === PaletteCommandVariables.Screen)
                    return this.apex.screens.map(s => s.name.toLowerCase());
                return [];
            }).flat();
            const scoredCommands = matchArrays(nextArgs, fuzzStrings(input, nextArgs))
                .filter((match) => match[1] !== undefined)
                .sort((a, b) => b[1] - a[1]);
            const bestMatch = scoredCommands[0];
            if (!bestMatch)
                return null;
            return bestMatch[0];
        }
        executeSignature(partialSig, input) {
            // If no input, find exact match on signature
            // TODO: Try fuzzy matching on signature, in case the input is a partial
            // match on the signature and not a variable
            const matches = this.sortedMatches(partialSig, input);
            if (matches.length === 0)
                return;
            const match = matches[0];
            if (input !== '') {
                const fuzzed = this.fuzzyNextArg(partialSig, input);
                if (fuzzed)
                    input = fuzzed;
                partialSig.push(input);
            }
            // Get indexes of variables in signature
            const indexes = [];
            match.signature.forEach((arg, i) => {
                if (isPaletteCommandVariable(arg))
                    indexes.push(i);
            });
            // Get values of variables in signature
            const variables = indexes.map((i) => partialSig[i]);
            match.command(...variables);
        }
    }
    __decorate([
        memoize()
    ], Palette.prototype, "signaturesMatches", null);
    __decorate([
        memoize()
    ], Palette.prototype, "signatureStartsWith", null);

    // ==UserScript==
    (function () {
        return __awaiter(this, void 0, void 0, function* () {
            console.debug('[PrUn Palette] Initializing...');
            const apex = new Apex();
            const keybinds = new Keybinds();
            const palette = new Palette(apex);
            // General commands
            palette.addCommand({
                name: 'Buffer',
                description: 'Open an empty buffer',
                command: () => apex.createBuffer(),
                signature: ['buffer'],
            });
            palette.addCommand({
                name: 'Buffer command',
                description: 'Open a buffer with a command',
                command: (command) => apex.createBuffer(command),
                signature: ['buffer', PaletteCommandVariables.Command],
            });
            // Contract commands
            palette.addCommand({
                name: 'Contracts',
                description: 'Open the contracts list',
                command: () => apex.createBuffer('CONTS'),
                signature: ['contract'],
            });
            palette.addCommand({
                name: 'Contract drafts',
                description: 'Open the contract drafts list',
                command: () => apex.createBuffer('CONTD'),
                signature: ['contract', 'drafts'],
            });
            // Screen commands
            palette.addCommand({
                name: 'Screen',
                description: 'Open a screen',
                command: (screen) => {
                    var _a;
                    return (_a = apex.screens
                        .find((s) => s.name.toLowerCase() === screen.toLowerCase())) === null || _a === void 0 ? void 0 : _a.open();
                },
                signature: ['screen', PaletteCommandVariables.Screen],
            });
            yield apex.ready;
            console.debug('[PrUn Palette] test', apex.screens);
            keybinds.addKeybind('<C-p>', () => palette.toggle());
            keybinds.addKeybind('escape', (preventDefault) => {
                if (palette.Open)
                    preventDefault();
                palette.close();
            }, { preventDefault: false });
            console.debug('[PrUn Palette] Ready!');
        });
    })();

})();
